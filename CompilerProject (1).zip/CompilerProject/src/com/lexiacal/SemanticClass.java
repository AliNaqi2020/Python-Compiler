package com.lexiacal;

import java.util.ArrayList;
import java.util.List;

public class SemanticClass {
    List<MainsymbolTable> mainTable =new ArrayList<MainsymbolTable>();


    public ArrayList<BodyTable>create_DT(){
        return new ArrayList<>();
    }
    public boolean insert_MT(String name,String type,String access_modifier,
                             String category,String parent,ArrayList<BodyTable> link){
       MainsymbolTable obj =new MainsymbolTable();

        obj.name=name;
        obj.type=type;
        obj.access_modifier=access_modifier;
        obj.category=category;
        obj.parent=parent;
        obj.link=link;

        mainTable.add(obj);
        System.out.println(mainTable);
        return true;
    }

    boolean insert_FT(String name,String type ){
        return true;
    }
    boolean insert_DT(){
        return true;
    }

}
