package com.lexiacal;

import java.util.ArrayList;

public class SyntaxAnalyzer {
    static int i=0;
    static ArrayList<tokenSet> token=new ArrayList<>();

    public SyntaxAnalyzer(ArrayList<tokenSet> tokens){
        token=tokens;
        System.out.println(token.get(0).VP);

    }

    public boolean CheckCFG() {
        if (entrypoint()) {
           if(token.get(i).CP.equals("$")){
            System.out.println("Valid CFG");
            return true;
            }
        }
        System.out.println("Error Occured AT Line Number" + token.get(i).line);
        return false;
    }

   public boolean entrypoint(){
        if (token.get(i).CP.equals("class")||
                token.get(i).CP.equals("struct")||
                token.get(i).CP.equals("static")||
                token.get(i).CP.equals("abstract")||
                token.get(i).CP.equals("sealed")){
            if(def_st()){
                if(CBS()){
                    if(c_body()) {
                        System.out.println("hello"+token.get(i).CP);
                        i++;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean def_st() {
         if(token.get(i).CP.equals("class")){
             i++;
             if (token.get(i).CP.equals("ID")){
                 i++;
                 if(W()){
                     if(def_st()){
                         return true;
                     }
                 }
             }
         }else if( token.get(i).CP.equals("struct")){
             i++;
             if( token.get(i).CP.equals("ID")){
                 i++;
                 if(def_stC()){
                     return true;
                 }
             }
         }else if( token.get(i).CP.equals("static")|| token.get(i).CP.equals("abstract")||
                 token.get(i).CP.equals("sealed")){
                 if(static_abstract_sealed()){
                     if(def_stD()){
                         return true;
                     }
                 }
             }
         return false;
    }

   public boolean CBS(){
        if( token.get(i).CP.equals("static")){
            i++;

            if(CB1()){

                return true;
            }
        }else if( token.get(i).CP.equals("abstract")){
            i++;
            if(CB2()){
                return true;
            }
        }else if( token.get(i).CP.equals("sealed")){
            i++;
            if(CB2()){
                return true;
            }
        }else if( token.get(i).CP.equals("class")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(CB3()){
                    return true;
                }
            }
        }else if( token.get(i).CP.equals("void")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(c_bodyA()){
                    return true;
                }
            }
        }
        return false;
   }

   public boolean c_body() {
       if (token.get(i).CP.equals("DT")) {
           if (DT()) {
               if (token.get(i).CP.equals("ID")) {
                   i++;
                   if (c_bodyA()) {
                       if (c_body()) {
                           return true;
                       }
                   }
               }
           }} else if (token.get(i).CP.equals("ID")) {
               i++;
               if (c_bodyA()) {
                   if (c_body()) {
                       return true;
                   }
               }
           }else if(( token.get(i).CP.equals("void"))||
               ( token.get(i).CP.equals("class"))||
               ( token.get(i).CP.equals("static"))||
               ( token.get(i).CP.equals("abstract"))||
               ( token.get(i).CP.equals("sealed"))
               ||(token.get(i).CP.equals("}"))){

           return true;
       } else if (( token.get(i).CP.equals("void"))||
                     ( token.get(i).CP.equals("class"))||
                     ( token.get(i).CP.equals("static"))||
                     ( token.get(i).CP.equals("abstract"))||
                     ( token.get(i).CP.equals("sealed"))){
               if(class_mod()){
                   if(CB4()){
                       return true;
                   }
           }
       }
       return false;
    }

    public boolean W(){
        if( token.get(i).CP.equals(":")|| token.get(i).CP.equals("{")){
            if(inheritance()){
                if( token.get(i).CP.equals("{")){
                    i++;
                    if(c_body()){
                        if( token.get(i).CP.equals("}")){
                            i++;
                            return true;
                        }
                    }
                }
            }
        }else if( token.get(i).CP.equals("class")||
                token.get(i).CP.equals("void")||
                token.get(i).CP.equals("static")||
                token.get(i).CP.equals("abstract")||
                token.get(i).CP.equals("sealed")||
                token.get(i).CP.equals("struct")){
            return true;
        }
        return false;
    }

    public boolean def_stC(){
        if( token.get(i).CP.equals("{")){
            i++;
            if(dec()){
                if( token.get(i).CP.equals("}")){
                    i++;
                    return true;
                }
            }
        }
        return false;
    }

    public boolean static_abstract_sealed(){
        if( token.get(i).CP.equals("static")){
            i++;
            return true;
        }else if( token.get(i).CP.equals("abstract")){
            i++;
            return  true;
        }else if ( token.get(i).CP.equals("sealed")){
            i++;
            return true;
        }
        return false;
    }

    public boolean def_stD(){
        if( token.get(i).CP.equals("class")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(W()) {
                    return true;
                }
            }
        }else if ( token.get(i).CP.equals("struct")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                return true;
            }
        }
    return false;
    }

    public boolean class_mod(){
        if( token.get(i).CP.equals("static")){
            i++;
            return true;
        }else if ( token.get(i).CP.equals("abstract")){
            i++;
            return true;
        }else if( token.get(i).CP.equals("sealed")){
            i++;
            return true;
        }else if ( token.get(i).CP.equals("void")||
                token.get(i).CP.equals("class")){
            i++;
            return true;
        }
     return false;
    }

    public boolean CB1(){
        if( token.get(i).CP.equals("void")){
            i++;
            if(main11()){
                return true;
            }
        }else if ( token.get(i).CP.equals("class")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(inheritance()){
                    if ( token.get(i).CP.equals("{")){
                        i++;
                        if(c_body()){
                            if(CB11()){
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean CB11(){
        if( token.get(i).CP.equals("}")) {
            i++;
            return true;
        }else{
            if(CBS()){
                if( token.get(i).CP.equals("}")){
                    i++;
                    return true;
                }
            }
        }
        return false;
    }

    public boolean CB2(){
        if( token.get(i).CP.equals("void")){
            i++;
           if( token.get(i).CP.equals("ID")){
               i++;
               if(c_bodyA()){
                   return true;
               }
           }
        }else if ( token.get(i).CP.equals("class")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(inheritance()){
                    if( token.get(i).CP.equals("{")){
                        i++;
                        if(c_body()){
                            if(CB11()){
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean CB3(){
        if( token.get(i).CP.equals(":")||
                token.get(i).CP.equals("{")){
            if(inheritance()){
                if( token.get(i).CP.equals("{")){
                    i++;
                    if(c_body()){
                        if(CB11()){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean CB4(){
        if( token.get(i).CP.equals("void")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(c_bodyA()){
                    return true;
                }
            }
        }else if( token.get(i).CP.equals("class")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(inheritance()){
                    if( token.get(i).CP.equals("{")){
                        i++;
                        if (c_body()){
                            if ( token.get(i).CP.equals("}")){
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean c_bodyA(){
        if( token.get(i).CP.equals("=")||
                token.get(i).CP.equals(";")||
                token.get(i).CP.equals(",")){
            if(init()){
                if(list()){
                    return true;
                }
            }
        }else if( token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if( token.get(i).CP.equals(")")){
                    i++;
                    if(body()){
                        return true;
                    }
                }
            }
        }
     return false;
    }

    public boolean inheritance(){
        if( token.get(i).CP.equals(":")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                return true;
            }
        }else if ( token.get(i).CP.equals("{")){
            return true;
        }
        return false;
    }

    public boolean dec(){
       if( token.get(i).VP.equals("static")||
               token.get(i).VP.equals("flt")||
               token.get(i).VP.equals("intgr")||
               token.get(i).VP.equals("char")||
               token.get(i).VP.equals("bool")||
               token.get(i).VP.equals("String")){
           if(static_var()){
               if(DT()){
                   if( token.get(i).CP.equals("ID")){
                       i++;
                       if(init()){
                           if(list()){
                               return true;
                           }
                       }
                   }
               }
           }
       }else if( token.get(i).CP.equals("ID")){
           i++;
           if(obj()){
               if( token.get(i).CP.equals(";")){
                   i++;
                   return true;
               }
           }
       }
       return false;
    }

    public boolean static_var(){
        if( token.get(i).CP.equals("static")){
            i++;
            return true;
        }else if( token.get(i).VP.equals("intgr")||
                token.get(i).VP.equals("flt")||
                token.get(i).VP.equals("bool")||
                token.get(i).VP.equals("char")||
                token.get(i).VP.equals("String")){
            i++;
            return true;
        }
        return false;
    }

    public boolean DT(){
        if( token.get(i).VP.equals("intgr")){
            i++;
            return true;
        }else if ( token.get(i).VP.equals("flt")){
            i++;
            return true;
        }else if( token.get(i).VP.equals("bool")){
            i++;
            return true;
        }else if( token.get(i).VP.equals("char")){
            i++;
            return true;
        }else if( token.get(i).VP.equals("String")){
            i++;
            return true;
        }
        return false;
    }

    public boolean main11(){
        if( token.get(i).CP.equals("ID")){
            i++;
            if( token.get(i).CP.equals("{")){
                i++;
                if(body()){
                    if( token.get(i).CP.equals("}")){
                        //i++;
                        return true;
                    }
                }
            }
        }else if( token.get(i).CP.equals("ID")){
            i++;
            if(main1()){
                return true;
            }
        }
        return false;
    }

    public boolean main1(){
        if( token.get(i).CP.equals("=")||
                token.get(i).CP.equals(";")||
                token.get(i).CP.equals(",")){
            if(init()){
                if(list()){
                    if(main()){
                        return true;
                    }
                }
            }
        }else if( token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if( token.get(i).CP.equals(")")){
                    i++;
                    if(body()){
                        if(main()){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean main(){
        if( token.get(i).CP.equals("void")){
            i++;
            if(main11()){
                return true;
            }
        }else if( token.get(i).CP.equals("class")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(inheritance()){
                    if ( token.get(i).CP.equals("{")){
                        i++;
                        if(c_body()){
                            if( token.get(i).CP.equals("}")){
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean init(){
        if( token.get(i).CP.equals("=")){
            i++;
            if(OE()){
                return  true;
            }
        }else if( token.get(i).CP.equals(";")|| token.get(i).CP.equals(",")) {
            return true;
        }
        return false;
    }

    public boolean list(){
        if( token.get(i).CP.equals(";")){
            i++;
            return true;
        }else if( token.get(i).CP.equals(",")){
            i++;
            if( token.get(i).CP.equals("ID")){
                i++;
                if(init()){
                    if(list()){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean parameter(){
        if( token.get(i).CP.equals("intgr")||
                token.get(i).CP.equals("flt")||
                token.get(i).CP.equals("char")||
                token.get(i).CP.equals("bool")||
                token.get(i).CP.equals("String")){
            if(DT()){
                if( token.get(i).CP.equals("ID")){
                    i++;
                    if(ParaA()){
                        return true;
                    }
                }
            }
        }else if( token.get(i).CP.equals(")")){
            return  true;
        }
        return false;
    }

    public boolean ParaA(){
        if( token.get(i).CP.equals("=")){
            i++;
            if(OE()){
                if(ParaB()){
                    return true;
                }
            }
        }else if ( token.get(i).CP.equals(",")|| token.get(i).CP.equals(")")){
            if(ParaB()){
                return true;
            }
        }
        return false;
    }

    public boolean ParaB(){
        if( token.get(i).CP.equals(",")){
            i++;
            if(parameter()){
                return true;
            }
        }else if( token.get(i).CP.equals(")")){
            return true;
        }
        return false;
    }

    public boolean body(){
        if( token.get(i).CP.equals(";")){
            i++;
            return true;
        }else if( token.get(i).CP.equals("for")|| token.get(i).CP.equals("if")|| token.get(i).CP.equals("while")||
                token.get(i).CP.equals("switch")|| token.get(i).CP.equals("do")|| token.get(i).CP.equals("continue")||
                token.get(i).CP.equals("break")|| token.get(i).CP.equals("return")|| token.get(i).CP.equals("static")||
                token.get(i).CP.equals("DT")|| token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")|| token.get(i).CP.equals("ID")){
            if(SST()){
                return true;
            }
        }else if(token.get(i).CP.equals("{")){
            i++;
            if(MST()){
                if(token.get(i).CP.equals("}")){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean obj(){
        if(token.get(i).CP.equals("ID")){
            i++;
            if(token.get(i).VP.equals("=")){

                i++;
                if(token.get(i).CP.equals("new")){

                    i++;
                    if(token.get(i).CP.equals("ID")){

                        i++;
                        if(token.get(i).CP.equals("(")){

                            if(OE()){


                                if(token.get(i).CP.equals(")")){
                                    i++;

                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean SST(){
        if(token.get(i).CP.equals("for")){
            if(for_st()){
                return  true;
            }
        }else if(token.get(i).CP.equals("if")){
            if(if_else()){
                return true;
            }
        }else if(token.get(i).CP.equals("while")){
            if(while_st()){
                return true;
            }
        }else if(token.get(i).CP.equals("do")){
            if(do_whilest()){
                return  true;
            }
        }else if(token.get(i).CP.equals("switch")){
            if(switch_st()){
                return true;
            }
        }else if(token.get(i).CP.equals("continue")){
            i++;
            if(token.get(i).CP.equals(";")){
                return true;
            }
        }else if(token.get(i).CP.equals("break")){
            i++;
            if(token.get(i).CP.equals(";")){
                return true;
            }
        }else if(token.get(i).CP.equals("return")){
            i++;
            if(OE()){
                if(token.get(i).CP.equals(";")){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("static")){
            i++;
            if(SST1()){
                return true;
            }
        }else if(token.get(i).CP.equals("DT")||token.get(i).CP.equals("String")){
            if(DT()){
                if(SST2()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")){
            if(inc_dec()){
                if(thiss()){
                    if(token.get(i).CP.equals("ID")){
                        i++;
                        if(X()){
                            if(token.get(i).CP.equals(";")){
                                return true;
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("ID")){
            if(SST3()){
                return true;
            }
        }
      return false;
    }

    public boolean for_st(){
        if(token.get(i).CP.equals("for")){
            i++;
            if(token.get(i).CP.equals("(")){
                i++;
                if(C1()){
                    if(C2()){
                        if(token.get(i).CP.equals(";")){
                            i++;
                            if(C3()){
                                if(token.get(i).CP.equals(")")){
                                    i++;
                                    if(body()){
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean C1(){
        if(token.get(i).CP.equals(";")){
            return true;
        }else if (token.get(i).CP.equals("static")||token.get(i).CP.equals("intgr")||token.get(i).CP.equals("flt")||
                token.get(i).CP.equals("bool")||token.get(i).CP.equals("char")||token.get(i).CP.equals("String")||
                token.get(i).CP.equals("ID")||token.get(i).CP.equals("this")){
            if(static_var()){
                if(DT()){
                    if(token.get(i).CP.equals("ID")){
                        i++;
                        if(init()){
                            if(list()){
                                return true;
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("ID")){
            i++;
            if(C5()){
                return true;
            }
        }else if(token.get(i).CP.equals("this")){
            i++;
            if(token.get(i).CP.equals(".")){
                i++;
                if(token.get(i).CP.equals("ID")){
                    i++;
                    if(X()){
                        if(init()){
                            if(list()){
                                if(token.get(i).CP.equals(";")){
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    public boolean C2(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")|| token.get(i).CP.equals("bool_const")||token.get(i).CP.equals("char_const")||
                token.get(i).CP.equals("String_const")){
            if(OE()){
                return true;
            }
        }else if(token.get(i).CP.equals(";")){
            return true;
        }
        return false;
    }

    public boolean C3(){
        if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")){
            if(inc_dec()){
                if(thiss()){
                    if(token.get(i).CP.equals("ID")){
                        i++;
                        if(X()){
                            if(token.get(i).CP.equals(";")){
                                return true;
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("this")){
            if(thiss()){
                if(token.get(i).CP.equals("ID")){
                    i++;
                    if(X()){
                        if(C6()){
                            return true;
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals(")")){
            return true;
        }
        return false;
    }

    public boolean inc_dec(){
        if(token.get(i).CP.equals("Unary Operator")){
            i++;
        return  true;
        }
        return false;
    }

    public boolean thiss(){
        if(token.get(i).CP.equals("this")){
           i++;
            if(token.get(i).CP.equals("dot")){
                i++;
                return true;
            }
        }else if(token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")){
            return true;
        }
        return false;
    }

    public boolean X(){
        if(token.get(i).CP.equals("dot")){
            i++;
            if(token.get(i).CP.equals("ID")){
                i++;
                if(X()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if(token.get(i).CP.equals(")")){
                    i++;
                    if(token.get(i).CP.equals("dot")){
                        i++;
                        if(token.get(i).CP.equals("ID")){
                            i++;
                            if(X()){
                                return true;
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("Assignment Operator")){
            i++;
            if(OE()) {
                return true;
            }
        }
        return false;
    }

    public boolean C5(){
        if(token.get(i).CP.equals("ID")){
            if(obj()){
                if(token.get(i).CP.equals(";")){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals(".")||token.get(i).CP.equals("(")||
                token.get(i).CP.equals("=")){
            if(X()){
                if(init()){
                    if(list()){
                        if(token.get(i).CP.equals(";")){
                            return  true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean C6(){
        if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")){
            if(inc_dec()){
                if(token.get(i).CP.equals(";")){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("=")||token.get(i).CP.equals(";")||token.get(i).CP.equals(",")){
            if(init()){
                if(list()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean MST(){
        if(token.get(i).CP.equals("for")||token.get(i).CP.equals("if")||token.get(i).CP.equals("while")||
                token.get(i).CP.equals("switch")||token.get(i).CP.equals("do")||token.get(i).CP.equals("continue")||
                token.get(i).CP.equals("break")||token.get(i).CP.equals("return")||token.get(i).CP.equals("static")||token.get(i).CP.equals("intgr")||
                token.get(i).CP.equals("flt")||token.get(i).CP.equals("char")||token.get(i).CP.equals("bool")||token.get(i).CP.equals("String")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("+")||token.get(i).CP.equals("ID")){
             if(SST()){
                 if(MST()){
                     return true;
                 }
             }
        }else if(token.get(i).CP.equals("}")){
            return true;
        }
        return false;
    }

    public boolean if_else(){
        if(token.get(i).CP.equals("if")){
            i++;
            if(token.get(i).CP.equals("(")){
                i++;
                if(OE()){
                    if(token.get(i).CP.equals(")")){
                        i++;
                        if(body()){
                            if(elsee()){
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean elsee(){
        if(token.get(i).CP.equals("else")){
            i++;
            if(body()){
                return true;
            }
        }else if(token.get(i).CP.equals("intgr")||token.get(i).CP.equals("flt")||token.get(i).CP.equals("char")||
                token.get(i).CP.equals("bool")||token.get(i).CP.equals("String")||token.get(i).CP.equals("static")||
                token.get(i).CP.equals("abstract")||token.get(i).CP.equals("sealed")||token.get(i).CP.equals("void")||
                token.get(i).CP.equals("class")||token.get(i).CP.equals("else")||token.get(i).CP.equals("break")||
                token.get(i).CP.equals("}")){
            return true;
        }
        return false;
    }

    public boolean while_st(){
        if(token.get(i).CP.equals("while")){
            i++;
            if(token.get(i).CP.equals("(")){
                i++;
                if(OE()){
                    if(token.get(i).CP.equals(")")){
                        i++;
                        if(body()){
                            return  true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean do_whilest(){
        if(token.get(i).CP.equals("do")){
            i++;
            if(token.get(i).CP.equals("{")){
                i++;
                if(MST()){
                    if(token.get(i).CP.equals("}")){
                        i++;
                        if(token.get(i).CP.equals("while")){
                            i++;
                            if(token.get(i).CP.equals("(")){
                                i++;
                                if(OE()){
                                    if(token.get(i).CP.equals(")")){
                                        i++;
                                        if(token.get(i).CP.equals(";")){
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean switch_st(){
        if(token.get(i).CP.equals("switch")){
            i++;
            if(token.get(i).CP.equals("(")){
                i++;
                if(OE()){
                    if(token.get(i).CP.equals(")")){
                        i++;
                        if(token.get(i).CP.equals("{")){
                            i++;
                            if(casee()){
                                if(token.get(i).CP.equals("}")){
                                    i++;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean casee(){
        if(token.get(i).CP.equals("default")){
            if(default_case()){
                return  true;
            }
        }else if(token.get(i).CP.equals("case")){
            i++;
            if(case1()){
                if(casee()){
                    return true;
                }
            }
        }
        return  false;
    }

    public boolean default_case(){
        if(token.get(i).CP.equals("default")){
            i++;
            if(token.get(i).CP.equals(":")){
                i++;
                if(body()){
                    if(token.get(i).CP.equals("break")){
                        i++;
                        if(token.get(i).CP.equals(";")){
                            return  true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean case1(){
        if(token.get(i).CP.equals("int_const")||token.get(i).CP.equals("bool_const")||token.get(i).CP.equals("flt_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("char_const")){
            if(constt()){
                if(token.get(i).CP.equals(":")){
                    i++;
                    if(body()){
                        if(token.get(i).CP.equals("break")){
                            i++;
                            if(token.get(i).CP.equals(";")){
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return  false;
    }

    public boolean constt(){
        if(token.get(i).CP.equals("int_const")){
            return  true;
        }else if(token.get(i).CP.equals("bool_const")){
            return true;
        }else if(token.get(i).CP.equals("flt_const")){
            return true;
        }else if(token.get(i).CP.equals("char_const")){
            return true;
        }else if(token.get(i).CP.equals("String_const")){
            return true;
        }
        return false;
    }

    public boolean SST1(){
        if(token.get(i).CP.equals("void")){
            i++;
            if(token.get(i).CP.equals("ID")){
                i++;
                if(token.get(i).CP.equals("(")){
                    i++;
                    if(parameter()){
                        if(token.get(i).CP.equals(")")){
                            i++;
                            if(body()){
                                return true;
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("intgr")||token.get(i).CP.equals("flt")||token.get(i).CP.equals("bool")
        ||token.get(i).CP.equals("char")||token.get(i).CP.equals("String")){
            if(DT()){
                if(token.get(i).CP.equals("ID")){
                    i++;
                    if(SS11()){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean SST2(){
        if(token.get(i).CP.equals("ID")){
            i++;
            if(init()){
                if(list()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("[")){
            i++;
            if(comma()){
                if(token.get(i).CP.equals("]")){
                    i++;
                    if(token.get(i).CP.equals("ID")){
                        i++;
                        if(token.get(i).CP.equals("=")){
                            i++;
                            if(token.get(i).CP.equals("new")){
                                i++;
                                if(DT()){
                                    if(token.get(i).CP.equals("[")){
                                        i++;
                                        if(OE()){
                                            if(comma()){
                                                if(C4()){
                                                    if(token.get(i).CP.equals("]")){
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
        }
        return false;
    }

    public boolean SST3(){
        if(token.get(i).CP.equals("dot")){
            i++;
            if(token.get(i).CP.equals("ID")){
                i++;
                if(X()){
                    if(SST111()){
                        return  true;
                    }
                }
            }
        }else if(token.get(i).CP.equals("=")){
            i++;
            if(OE()){
                if(SST111()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if(token.get(i).CP.equals(")")){
                    i++;
                    if(semicolon()){
                        return true;
                    }
                }
            }
        }else if(token.get(i).CP.equals("ID")){
            if(obj()){
                if(token.get(i).CP.equals(";")){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("[")){
            i++;
            if(OE()){
                if(comma()){
                    if(C4()){
                        if(token.get(i).CP.equals("]")){
                            i++;
                            if(token.get(i).CP.equals("=")){
                                i++;
                                if(OE()){
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if(token.get(i).CP.equals(")")){
                    i++;
                    if(semicolon()){
                        if(SST3()){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean SS11(){
        if(token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if(token.get(i).CP.equals(")")){
                    i++;
                    if(body()){
                        return true;
                    }
                }
            }
        }else if(token.get(i).CP.equals("=")||token.get(i).CP.equals(";")||token.get(i).CP.equals(",")){
            if(init()){
                if(list()){
                    return  true;
                }
            }
        }
    return false;
    }

    public boolean SST111(){
        if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")){
            i++;
            if(inc_dec()){
                if(token.get(i).CP.equals(";")){
                i++;
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("intgr")||token.get(i).CP.equals("flt")||token.get(i).CP.equals("char")||
                token.get(i).CP.equals("bool")||token.get(i).CP.equals("String")||token.get(i).CP.equals("ID")||
                token.get(i).CP.equals("void")||token.get(i).CP.equals("class")||token.get(i).CP.equals("static")||
                token.get(i).CP.equals("abstract")||token.get(i).CP.equals("sealed")||token.get(i).CP.equals("else")||
                token.get(i).CP.equals("break")||token.get(i).CP.equals("}")){
            i++;
            return true;
        }
        return false;
    }

    public boolean MA(){
        if(token.get(i).CP.equals("intgr")||token.get(i).CP.equals("flt")||token.get(i).CP.equals("char")||
                token.get(i).CP.equals("bool")||token.get(i).CP.equals("String")){
            i++;
            if(DT()){
                if(token.get(i).CP.equals("[")){
                    i++;
                    if(comma()){
                        if(token.get(i).CP.equals("]")){
                            i++;
                            if(token.get(i).CP.equals("ID")){
                                i++;
                                if(token.get(i).CP.equals("=")){
                                    i++;
                                    if(token.get(i).CP.equals("new")){
                                        i++;
                                        if(DT()){
                                            if(token.get(i).CP.equals("[")){
                                                i++;
                                                if(OE()){
                                                    if(comma()){
                                                        if(C4()){
                                                            if(token.get(i).CP.equals("]")){
                                                            i++;
                                                                return true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean comma(){
        if(token.get(i).CP.equals(",")){
            i++;
            if(comma()){
                return true;
            }
        }else if(token.get(i).CP.equals("]")||token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")||token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||
                token.get(i).CP.equals("int_const")||token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("char_const")||token.get(i).CP.equals("String_const")){
            i++;
            return true;
        }
        return false;
    }

    public boolean C4(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            i++;
            if(OE()){
                if(comma()){
                    if(C4()){
                        return true;
                    }
                }
            }else if(token.get(i).CP.equals("]")){
                i++;
                return true;
            }
        }
        return false;
    }

    public boolean semicolon(){
        if(token.get(i).CP.equals(";")){
            i++;
            return true;
        }else if(token.get(i).CP.equals(".")||token.get(i).CP.equals("=")||token.get(i).CP.equals("(")||
                token.get(i).CP.equals("ID")||token.get(i).CP.equals("[")||token.get(i).CP.equals("intgr")||
                token.get(i).CP.equals("flt")||token.get(i).CP.equals("bool")||token.get(i).CP.equals("char")||
                token.get(i).CP.equals("String")||token.get(i).CP.equals("static")||token.get(i).CP.equals("abstract")||
                token.get(i).CP.equals("sealed")||token.get(i).CP.equals("else")||token.get(i).CP.equals("break")||
                token.get(i).CP.equals("}")||token.get(i).CP.equals("void")||token.get(i).CP.equals("class")){
            i++;
            return true;
        }
        return  false;
    }

    public boolean OE(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            if(AE()){
                if(OE1()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean OE1(){
        if(token.get(i).CP.equals("||")){
            i++;
            if(AE()){
                if(OE1()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            i++;
            return true;
        }
        return  false;
    }

    public boolean AE(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            if(RE()){
                if(AE1()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean AE1(){
        if(token.get(i).CP.equals("&&")){
            i++;
            if(RE()){
                if(AE1()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("||")||token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            return true;
        }
        return  false;
    }

    public boolean RE(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            if(SE()){
                if(RE1()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean RE1(){
        if(token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")){
            i++;
            if(SE()){
                if(RE1()){
                    return true;
                }
            }
        }else if(token.get(i).equals("&&")||token.get(i).CP.equals("||")||token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            return true;
        }
        return  false;
    }

    public boolean SE(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            if(E()){
                if(SE1()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean SE1(){
        if(token.get(i).CP.equals(">>")||token.get(i).CP.equals("<<")){
            i++;
            if(E()){
                if(SE1()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")||token.get(i).equals("&&")||token.get(i).CP.equals("||")||token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            return true;
        }
        return  false;
    }

    public boolean E(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            if(T()){
                if(E1()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean E1(){
        if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")){
            i++;
            if(T()){
                if(E1()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals(">>")||token.get(i).CP.equals("<<")||token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")||token.get(i).equals("&&")||token.get(i).CP.equals("||")||token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){

            return true;
        }
        return  false;
    }

    public boolean T(){
        if(token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||token.get(i).CP.equals("+")||
                token.get(i).CP.equals("-")||token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")
                ||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")){
            if(F()){
                if(T1()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean T1(){
        if(token.get(i).CP.equals("*")||token.get(i).CP.equals("%")||token.get(i).CP.equals("/")){
            i++;
            if(F()){
                if(T1()){
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")||token.get(i).CP.equals(">>")||
                token.get(i).CP.equals("<<")||token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||
                token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")||
                token.get(i).equals("&&")||token.get(i).CP.equals("||")||
                token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||
                token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            return true;
        }
        return  false;
    }

    public boolean F(){
        if(token.get(i).CP.equals("(")){
            if(OE()){
                if(token.get(i).CP.equals(")")){
                i++;
                    return true;
                }
            }
        }else if(token.get(i).CP.equals("Unary Operator")){
            i++;
            if(F()){
                return true;
            }
        }else if(token.get(i).CP.equals("+")||token.get(i).CP.equals("-")){
            if(inc_dec()){
                if(thiss()){
                    if(token.get(i).CP.equals("ID")){
                        i++;
                        if(X()){
                            if(token.get(i).CP.equals(";")){
                               i++;
                                return true;
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")){
            if(thiss()){
                if(token.get(i).CP.equals("ID")){
                    if(Z()){
                        return true;
                    }
                }
            }
        }else if(token.get(i).CP.equals("int_const")||token.get(i).CP.equals("flt_const")||
                token.get(i).CP.equals("bool_const")||token.get(i).CP.equals("String_const")||
                token.get(i).CP.equals("char_const")){
            if(constt()){
                return true;
            }
        }
        return false;
    }

    public boolean Z(){
        if(token.get(i).CP.equals(".")||token.get(i).CP.equals("(")||token.get(i).CP.equals("=")){
            if(X()){
                if(inc_dec()){
                    if(token.get(i).CP.equals(";")){
                i++;
                        return true;
                    }
                }
            }
        }else if(token.get(i).CP.equals("*")||token.get(i).CP.equals("/")||token.get(i).CP.equals("%")||
                token.get(i).CP.equals(".")||token.get(i).CP.equals("[")||
                token.get(i).CP.equals("+")||token.get(i).CP.equals("-")||token.get(i).CP.equals(">>")||
                token.get(i).CP.equals("<<")||token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||
                token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")||
                token.get(i).equals("&&")||token.get(i).CP.equals("||")||
                token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||
                token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            if(F1()){
                return true;
            }
        }
        return false;
    }

    public boolean F1(){
        if( token.get(i).CP.equals(".")){
            i++;
            if(P()){
                return true;
            }
        }else if( token.get(i).CP.equals("[")){
            i++;
            if(OE()){
                if(comma()){
                    if(C4()){
                        if( token.get(i).CP.equals("]")){
                            i++;
                            if( token.get(i).CP.equals(".")){
                                i++;
                                if( token.get(i).CP.equals("ID")){
                                    i++;
                                    if(F1()){
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }else if(token.get(i).CP.equals("*")||token.get(i).CP.equals("/")||token.get(i).CP.equals("%")||
                token.get(i).CP.equals("+")||token.get(i).CP.equals("-")||token.get(i).CP.equals(">>")||
                token.get(i).CP.equals("<<")||token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||
                token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")||
                token.get(i).equals("&&")||token.get(i).CP.equals("||")||
                token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||
                token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            return true;
        }
        return false;
    }

    public boolean P(){
        if(token.get(i).CP.equals("ID")){
            i++;
            if(Q()) {
                return true;
            }
        }
        return false;
    }

    public boolean Q(){
        if(token.get(i).CP.equals("*")||token.get(i).CP.equals("/")||token.get(i).CP.equals("%")||
                token.get(i).CP.equals("+")||token.get(i).CP.equals("-")||token.get(i).CP.equals(">>")||
                token.get(i).CP.equals("<<")||token.get(i).CP.equals(">")||token.get(i).CP.equals("<")||
                token.get(i).CP.equals(">=")||token.get(i).CP.equals("<=")||
                token.get(i).CP.equals("!=")||token.get(i).CP.equals("==")||
                token.get(i).equals("&&")||token.get(i).CP.equals("||")||
                token.get(i).CP.equals("(")||token.get(i).CP.equals("!")||
                token.get(i).CP.equals("+")|| token.get(i).CP.equals("-")||
                token.get(i).CP.equals("this")||token.get(i).CP.equals("ID")||token.get(i).CP.equals("int_const")||
                token.get(i).CP.equals("flt_const")||token.get(i).CP.equals("char_const")||token.get(i).CP.equals("bool_const")||
                token.get(i).CP.equals("String_const")||token.get(i).CP.equals("]")){
            i++;
            if(F1()){
                return true;
            }
        }else if( token.get(i).CP.equals("(")){
            i++;
            if(parameter()){
                if( token.get(i).CP.equals(")")){
                    i++;
                    if(semicolon()){
                        if(F1()){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }


}



