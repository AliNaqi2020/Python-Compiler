package com.lexiacal;

public class FunctionTable {
    public String name;
    public String type;
    public int scope;
}
